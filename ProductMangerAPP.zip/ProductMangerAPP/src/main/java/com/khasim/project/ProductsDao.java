package com.khasim.project;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class ProductsDao{ 
            public int save(Products p) {
        		Connection c=null;
        		PreparedStatement ps=null;
        		int savecount=0;
        		try {
        			//get connection
        			c=ProductsUtils.Connection();
        			ps=c.prepareStatement("insert into product_data values(?,?,?,?,?,?,?,?)");
        			//set inputs
        			ps.setString(1, p.getProId());
                    ps.setString(2, p.getProName());
                    ps.setDouble(3, p.getProPrice());
                    ps.setString(4, p.getProBrand());
                    ps.setString(5, p.getProMadein());
                    ps.setDate(6, p.getProMfgdate());
                    ps.setDate(7, p.getProExpdate());
                    ps.setBytes(8, p.getProImage());
                    //execute Query
        			savecount=ps.executeUpdate();
        		}
        		catch(SQLException e) {
        			e.printStackTrace();
        		}
        		finally {
        			try {
        				if(ps!=null)
            				ps.close();
        			if(c!=null)
        				c.close();
        			
        		}
        		catch(SQLException s) {
        			s.printStackTrace();
        		}
        		}
        		return savecount;
        	}
public static List<Products> findAll(){
	List<Products> productlist=new ArrayList<Products>();
	try(Connection c=ProductsUtils.Connection();Statement s=c.createStatement())
	{
		ResultSet set=s.executeQuery("select * from product_data");
		while(set.next()) {
			Products p=new Products();
			p.setProId(set.getString("proId"));
			p.setProName(set.getString("proName"));
			p.setProPrice(set.getDouble("proPrice"));
			p.setProBrand(set.getString("proBrand"));
			p.setProMadein(set.getString("proMadein"));
			p.setProMfgdate(set.getDate("proMfgdate"));
			p.setProExpdate(set.getDate("proExpdate"));
			p.setProImage(set.getBytes("proImage"));
			productlist.add(p);
			
		}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return productlist;	
	}
}